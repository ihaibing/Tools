/*
 * function prototype for tx_box()
 */
void tx_box(WINDOW *win, int vline, hline);
