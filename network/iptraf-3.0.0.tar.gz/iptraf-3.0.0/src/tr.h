/*
 * tr.h - prototype for Token Ring header parser.
 */

unsigned int get_tr_ip_offset(unsigned char *pkt);
