void write_error(char *msg, int daemonized);
