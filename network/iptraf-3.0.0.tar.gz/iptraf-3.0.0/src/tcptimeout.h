void write_timeout_log(int logging, FILE * logfile,
                       struct tcptableent *tcpnode, struct OPTIONS *opts);
